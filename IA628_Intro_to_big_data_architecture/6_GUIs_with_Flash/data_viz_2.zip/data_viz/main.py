from flask import Flask
from flask import request,session, redirect, url_for, escape,send_from_directory,make_response

import pymysql,json, operator


app = Flask(__name__, static_url_path='')


@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

@app.route('/')
def main():
    return 'Test'

@app.route('/plot_test')
def plot_test():
    y = [5,4,7,6,2,8,7,6,5,7,8]
    n=len(y)
    x = [n for n in range(n)]
    return '''
    <head>
          <!-- Plotly.js -->
          <script src="/static/plotly-latest.min.js"></script>
        </head>
        <body>
          <div id="myDiv"></div>
        </body> 
         <script>
          
          var trace1 = {
              x: '''+json.dumps(x)+''',
              y: '''+json.dumps(y)+''',
              type: 'scatter',
            };

            var trace2 = {
              x: [1, 2, 3, 4],
              y: [16, 5, 11, 9],
              type: 'scatter'
            };

            var data = [trace1, trace2];

            Plotly.newPlot('myDiv', data, {}, {showSendToCloud: true});
          </script>
    '''

@app.route('/dailyTickets')
def dailyTickets():
    conn = pymysql.connect(host='mysql.clarksonmsda.org', port=3306, user='ia626',
                       passwd='ia626clarkson', db='ia626', autocommit=True)

    cur = conn.cursor(pymysql.cursors.DictCursor)
    
    sql = '''SELECT COUNT( * ) AS `Rows` , `issuedate`
          FROM `moellebr_pv` GROUP BY `issuedate` ORDER BY `issuedate`'''
    cur.execute(sql)
    y = []
    x = []
    for row in cur:
        y.append(row['Rows'])
        x.append(str(row['issuedate']))
    return '''
    <head>
          <!-- Plotly.js -->
          <script src="/static/plotly-latest.min.js"></script>
        </head>
        <body>
          <div id="myDiv"></div>
        </body> 
         <script>
          
          var trace1 = {
              x: '''+json.dumps(x)+''',
              y: '''+json.dumps(y)+''',
              type: 'scatter',
            };

            var data = [trace1];

            Plotly.newPlot('myDiv', data, {}, {showSendToCloud: true});
          </script>
    '''
@app.route('/states',methods=['POST','GET'])
def states():
    date = request.form.get('date')
    
    
    conn = pymysql.connect(host='mysql.clarksonmsda.org', port=3306, user='ia626',
                       passwd='ia626clarkson', db='ia626', autocommit=True)

    cur = conn.cursor(pymysql.cursors.DictCursor)
    
    if date is None:
        sql = '''SELECT COUNT( * ) AS `Rows` , `regstate`
                FROM `moellebr_pv`
                GROUP BY `regstate`
                ORDER BY  `Rows` DESC

                '''
        cur.execute(sql)
    else:
        sql = '''SELECT COUNT( * ) AS `Rows` , `regstate`
                FROM `moellebr_pv`
                WHERE `issuedate` = %s
                GROUP BY `regstate` 

                '''
        cur.execute(sql,(date))
    y = []
    x = []
    for row in cur:
        y.append(row['Rows'])
        x.append(str(row['regstate']))
    return '''
    <head>
          <!-- Plotly.js -->
          <script src="/static/plotly-latest.min.js"></script>
        </head>
        <body>
          <div id="myDiv"></div>
        </body> 
         <script>
          
         var data = [{
              values: '''+json.dumps(y)+''',
              labels: '''+json.dumps(x)+''',
              type: 'pie'
            }];

            var layout = {
              height: 400,
              width: 500
            };

            Plotly.newPlot('myDiv', data, layout);
          </script>
    '''    
    
@app.route('/byDate')
def byDate():
    conn = pymysql.connect(host='mysql.clarksonmsda.org', port=3306, user='ia626',
                       passwd='ia626clarkson', db='ia626', autocommit=True)

    cur = conn.cursor(pymysql.cursors.DictCursor)
    
    sql = '''SELECT `issuedate`
        FROM `moellebr_pv`
        GROUP BY `issuedate`
        ORDER BY `issuedate`'''
    
    cur.execute(sql)
    
    html = ''
    for row in cur:
        html += '<option value="'+str(row['issuedate'])+'">'+str(row['issuedate'])+'</option>\n'
    
    return '''
    <html>
     <head>
        
        </head>
        <body>
          <form action="/states" method="GET">
                <select name="date">
                    '''+html+'''
                </select>
                <input type="Submit"/>
          </form>
        </body> 
      </html>
    
    '''
    
    
    
    
    
    
    
    

if __name__ == "__main__":
    app.run(host='127.0.0.1',debug=True)